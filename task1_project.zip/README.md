# TrialGPT Criterion Eligibility Fine-Tuning (Task 1)

This project implements the first assignment task using the required NLM TrialGPT Criterion Annotations dataset. It creates the fixed patient-grouped split, excludes all GPT-4 generated fields from model input, fine-tunes an open-weight decoder model, and evaluates the same validation/test records before and after fine-tuning.

## Chosen model and feasibility

Primary model: `Qwen/Qwen2.5-0.5B-Instruct` (0.49B parameters, decoder-only causal Transformer, Apache-2.0, Qwen2 tokenizer, model-card context up to 32,768 tokens). FP16/BF16 weights require about 1 GB, while 4-bit weights require roughly 0.3–0.5 GB before runtime/cache overhead. LoRA training with sequence length 2048, microbatch 1, gradient accumulation 8, and gradient checkpointing is practical on a free 8–16 GB GPU; CPU training is technically possible but slow. The active machine currently has no PyTorch installation and no detected CUDA GPU, so no local training results are claimed.

Candidate: `HuggingFaceTB/SmolLM2-360M-Instruct` (0.36B parameters, decoder-only Llama-style causal Transformer, Apache-2.0, 8K context per model card). Its smaller weights reduce memory, but Qwen's longer context and stronger multilingual/instruction-tuning profile make Qwen preferable for patient-note conditioning. Both have compatible open-weight causal-generation architectures. Exact model metadata and license should be rechecked at download time.

## Reproduce

Use Python 3.10–3.12 and a free Kaggle/Colab GPU (or local CUDA). Install `requirements.txt`; then:

```bash
python src/prepare_data.py --out data/processed
python src/train.py --config configs/qwen_lora.json
python src/evaluate.py --config configs/qwen_lora.json --split validation
python src/evaluate.py --config configs/qwen_lora.json --split test
```

Run the final test evaluation only after selecting hyperparameters from validation. Artifacts go to `outputs/`; do not commit large weights. Use `outputs/split_manifest.json`, training logs, and evaluation JSONs in the report.

## Data and leakage controls

The source is `ncbi/TrialGPT-Criterion-Annotations` from Hugging Face. `prepare_data.py` sorts unique patient IDs, shuffles with `numpy.random.default_rng(42)`, and allocates 37/8/8 patients. It saves patient IDs and row counts and asserts disjoint groups. Inputs use only `note`, `criterion_type`, and `criterion_text`; targets use `expert_eligibility` and `expert_sentences`. The columns `gpt4_explanation`, `gpt4_sentences`, `gpt4_eligibility`, and `explanation_correctness` are explicitly excluded.

Patient notes already contain numbered sentences (for example `0. ... 1. ...`). The output must be JSON with `eligibility` in the source expert label vocabulary and `evidence_sentence_ids` as integer IDs drawn from that note. Empty evidence is allowed. Evidence IDs are learned as target text; invalid IDs are counted in evaluation.

## Truncation

Tokenization uses the model's native tokenizer and truncates inputs to 2048 tokens by default, retaining the beginning of the concatenated prompt. This can remove later clinical evidence; the script records tokenized input length, truncation flag, and source note length per example. For the report, include the fraction truncated and inspect those cases. Do not silently claim evidence completeness for truncated notes. Increase `max_length` if free GPU memory permits.

## Experimental design

Supervised objective: causal next-token cross-entropy on the structured target JSON only; prompt tokens receive label `-100`. LoRA rank 8, alpha 16, dropout 0.05, target modules `q_proj`, `k_proj`, `v_proj`, `o_proj`; AdamW learning rate 2e-4, 3 epochs, effective batch 8, warmup ratio 0.05, seed 42. Save the best checkpoint by validation macro-F1. Greedy decoding (`do_sample=False`, temperature omitted) uses the same prompt/template and max 128 new tokens for base and tuned models.

Evaluation includes accuracy, macro-F1, class-wise precision/recall/F1, confusion matrix and evidence precision/recall/F1 over exact sentence IDs. Empty gold/predicted evidence pairs score 1 for precision/recall/F1; one empty and one nonempty scores 0. Test metrics must be generated only once after configuration is fixed.

## Current execution status

No training, validation, or test metrics are included until this project is run in an environment with dependencies and the public dataset available. Do not use placeholder values as results. GPU model and peak memory, training curves, validation-selected epoch, test scores, runtime, and failure examples must be added from actual logs.

## Research sources

See `report/references.bib` and `report/task1.tex`. Sources include the TrialGPT paper, Transformer architecture, Qwen and SmolLM2 model cards/papers, LoRA, and FlashAttention. The report draft is explicit about unmeasured results.
