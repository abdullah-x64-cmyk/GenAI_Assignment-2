import json, re

LABELS = ["included", "excluded", "not enough information", "not applicable"]

def parse_evidence(value):
    if isinstance(value, list): return [int(x) for x in value]
    if value is None: return []
    if isinstance(value, (int, float)): return [int(value)]
    try:
        obj = json.loads(value)
        if isinstance(obj, list): return [int(x) for x in obj]
    except Exception: pass
    return [int(x) for x in re.findall(r"\d+", str(value))]

def target_for(row):
    label = str(row["expert_eligibility"]).strip().lower()
    return json.dumps({"eligibility": label, "evidence_sentence_ids": parse_evidence(row["expert_sentences"])}, ensure_ascii=False)

def prompt_for(row):
    return ("You are a clinical-trial criterion screening research model. Use only the patient note. "
            "Return one JSON object with eligibility and evidence_sentence_ids. Eligibility must preserve the expert label category; "
            "do not infer from missing information. Evidence IDs must be sentence numbers explicitly present in the note.\n"
            f"Patient note:\n{row['note']}\nCriterion type: {row['criterion_type']}\nCriterion: {row['criterion_text']}\nJSON response:")
