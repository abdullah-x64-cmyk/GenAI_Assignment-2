import argparse, json, re, time
from pathlib import Path
import numpy as np
import torch
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import PeftModel
from common import prompt_for, parse_evidence

def read_rows(p): return [json.loads(x) for x in Path(p).read_text(encoding="utf-8").splitlines() if x]
def output_fields(s):
    s=s.strip()
    try: obj=json.loads(s[s.find("{"):s.rfind("}")+1])
    except Exception: obj={}
    label=str(obj.get("eligibility","invalid")).strip().lower()
    evidence=parse_evidence(obj.get("evidence_sentence_ids",[]))
    return label,evidence
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--config",default="configs/qwen_lora.json"); ap.add_argument("--split",choices=["validation","test"],required=True); ap.add_argument("--mode",choices=["base","finetuned"],default="finetuned"); a=ap.parse_args()
    c=json.loads(Path(a.config).read_text()); rows=read_rows(f"data/processed/{a.split}.jsonl")
    tok=AutoTokenizer.from_pretrained(c["model_name"]); model=AutoModelForCausalLM.from_pretrained(c["model_name"],torch_dtype="auto",device_map="auto")
    if a.mode=="finetuned": model=PeftModel.from_pretrained(model,f"{c['output_dir']}/best_adapter")
    model.eval(); gold=[]; pred=[]; ge=[]; pe=[]; outputs=[]; truncs=[]; lat=[]
    for r in rows:
        prompt=prompt_for(r); encoded=tok(prompt,return_tensors="pt",truncation=True,max_length=c["max_length"]-c["max_new_tokens"])
        truncs.append(len(tok(prompt,add_special_tokens=False)["input_ids"])>c["max_length"]-c["max_new_tokens"])
        encoded={k:v.to(model.device) for k,v in encoded.items()};
        if torch.cuda.is_available(): torch.cuda.synchronize()
        t=time.perf_counter()
        with torch.inference_mode(): out=model.generate(**encoded,max_new_tokens=c["max_new_tokens"],do_sample=False,pad_token_id=tok.eos_token_id,use_cache=True)
        if torch.cuda.is_available(): torch.cuda.synchronize()
        lat.append(time.perf_counter()-t); raw=tok.decode(out[0,encoded["input_ids"].shape[-1]:],skip_special_tokens=True)
        label,ev=output_fields(raw); gold.append(str(r["expert_eligibility"]).strip().lower()); pred.append(label)
        gold_ev=set(parse_evidence(r["expert_sentences"])); pred_ev=set(ev); ge.append(gold_ev); pe.append(pred_ev)
        outputs.append({"patient_id":r["patient_id"],"criterion_type":r["criterion_type"],"gold_label":gold[-1],"predicted_label":label,"gold_evidence_ids":sorted(gold_ev),"predicted_evidence_ids":sorted(pred_ev),"raw_output":raw,"truncated":truncs[-1]})
    labels=sorted(set(gold)|set(pred)); evtp=sum(len(x&y) for x,y in zip(ge,pe)); evp=sum(map(len,pe)); evg=sum(map(len,ge))
    # Micro set metrics with empty/empty counted as correct for per-example macro evidence F1.
    p=evtp/evp if evp else (1.0 if evg==0 else 0.0); rec=evtp/evg if evg else (1.0 if evp==0 else 0.0); f1=2*p*rec/(p+rec) if p+rec else 0.0
    metrics={"split":a.split,"mode":a.mode,"n":len(rows),"accuracy":accuracy_score(gold,pred),"macro_f1":f1_score(gold,pred,labels=labels,average="macro",zero_division=0),"class_report":classification_report(gold,pred,labels=labels,output_dict=True,zero_division=0),"labels":labels,"confusion_matrix":confusion_matrix(gold,pred,labels=labels).tolist(),"evidence_micro_precision":p,"evidence_micro_recall":rec,"evidence_micro_f1":f1,"truncated_fraction":float(np.mean(truncs)),"mean_generation_seconds":float(np.mean(lat)),"predictions":outputs}
    out=Path("outputs/evaluation"); out.mkdir(parents=True,exist_ok=True); path=out/f"{a.split}_{a.mode}.json"; path.write_text(json.dumps(metrics,indent=2),encoding="utf-8"); print(json.dumps({k:v for k,v in metrics.items() if k not in ("class_report","confusion_matrix","predictions")},indent=2))
if __name__=="__main__": main()
